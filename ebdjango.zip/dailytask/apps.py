from django.apps import AppConfig


class DailytaskConfig(AppConfig):
    name = 'dailytask'
